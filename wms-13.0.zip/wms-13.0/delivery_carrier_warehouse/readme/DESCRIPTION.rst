This module allows to define a delivery carrier on stock warehouse.

If a partner does not have a default carrier defined, the 'Add shipping' wizard
will use the carrier defined on the warehouse as default.
