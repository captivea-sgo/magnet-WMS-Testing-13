This module adds a new screen to handle stock receptions step by step, e.g:

  * select/scan product to receive
  * scan lot to create
  * set expiry date
  * set the quantity received

And loop until the reception is done.
