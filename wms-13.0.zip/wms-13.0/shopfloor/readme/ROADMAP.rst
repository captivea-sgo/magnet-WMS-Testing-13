* improve documentation
* split out scenario components to their own modules
