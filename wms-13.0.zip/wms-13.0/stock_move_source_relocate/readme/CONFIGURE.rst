The configuration of the source relocations is done in "Inventory > Configuration > Source Relocation".

Creation of a rule:

Properties that define where the rule will be applied:

* Location: any unreserved move in this location or sub-location is relocated
* Picking Type: any unreserved move in this picking type is relocated
* Rule Domain: filter the moves to relocate with arbitrary domains

Note: all of the above must be met to relocate a move.

The Relocate Location field defines what the move source location will be changed to. It must be a sub-location of the location.
