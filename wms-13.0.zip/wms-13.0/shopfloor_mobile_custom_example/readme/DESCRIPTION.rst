Example on how to override the frontend for Shopfloor app.
