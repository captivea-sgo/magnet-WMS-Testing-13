* Make all strings translatable
* Document demo mode
* Split core and scenario
* Improve inheritance/override
* Add more examples
