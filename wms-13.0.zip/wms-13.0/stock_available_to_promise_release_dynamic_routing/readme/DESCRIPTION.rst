Glue module between ``stock_available_to_promise_release`` and
``stock_dynamic_routing``.

Currently, the module only contains tests to verify the compatibility
between these two modules, but compatibility code may be needed later.
