When an outgoing transfer would generate chained moves, it will not. The chained
moves need to be released manually. To do so, open "Inventory > Operations >
Stock Allocation", select the moves to release and use "action > Release
Stock Move". A move can be released only if the available to promise quantity is
greater than zero. This quantity is computed as the product's virtual quantity
minus the previous moves in the list (previous being defined by the field
"Priority Date").
