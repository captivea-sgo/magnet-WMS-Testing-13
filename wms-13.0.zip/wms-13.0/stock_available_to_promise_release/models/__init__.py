from . import product_product
from . import stock_move
from . import stock_location_route
from . import stock_picking
from . import stock_picking_type
from . import stock_rule
from . import res_company
from . import res_config_settings
