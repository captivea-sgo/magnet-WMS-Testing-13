Technical module to make the following addons work properly together:

* ``stock_picking_type_shipping_policy``
* ``stock_picking_group_by_partner_by_carrier``
