Glue module between ``stock_move_source_relocate`` and
``stock_dynamic_routing``.
