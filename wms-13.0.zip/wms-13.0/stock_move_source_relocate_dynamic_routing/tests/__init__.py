from . import test_dynamic_relocate
