This module implements chaotic storage 'ABC' according to Package Storage Type
and Location Storage Type.
