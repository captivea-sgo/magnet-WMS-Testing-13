* Denis Robinet <denis.robinet@acsone.eu>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Quentin Groulard <quentin.groulard@acsone.eu>
* Sébastien Beau <sebastien.beau@akretion.com>