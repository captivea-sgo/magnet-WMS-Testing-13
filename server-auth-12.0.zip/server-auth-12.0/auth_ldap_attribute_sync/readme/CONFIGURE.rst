To configure this module, you need to:

#. Access Settings / General Settings / LDAP Authentication / LDAP Server
#. Configure attributes mapping according to the LDAP server configuration
