This module allows to update users’ fields from LDAP attributes.
