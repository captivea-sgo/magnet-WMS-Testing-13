This module adds support for FIDO U2F token based authentication.
It allows users to enable/disable MFA and manage authentication apps/devices
via the "Change My Preferences" view and an associated wizard. The server must run HTTPS to
work properly.

After logging in, users with registered U2F devices are taken to a second screen
where they have authenticate using device.
