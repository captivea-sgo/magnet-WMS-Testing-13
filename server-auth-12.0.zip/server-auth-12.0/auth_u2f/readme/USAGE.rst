After logging in, set up a U2F device through the user preferences. Click on ‘Manage 2-step verification'
and create a new device by filling a name and scanning the device.

.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Try me on Runbot
   :target: https://runbot.odoo-community.org/runbot/251/12.0
