To use this module, you need to:

#. Open Odoo in your browser
#. Go to Settings
#. Go to General Settings
#. In The General Settings form go to LDAP Parameters
#. In a LDAP Parameters item there are two new fields: mail and name, the name
   These items will correspond with a new user that is created, when a user
   logs in via LDAP in Odoo.
