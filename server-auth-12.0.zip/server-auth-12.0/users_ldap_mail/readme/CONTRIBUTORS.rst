* Daniel Reis (https://launchpad.com/~dreis-pt),
* `Tecnativa <https://www.tecnativa.com>`_:

  * Alexandre Díaz
