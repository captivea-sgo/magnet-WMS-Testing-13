This addon requires `lasso`_.

.. _lasso: http://lasso.entrouvert.org
