2.0
~~~

* SAML tokens are not stored in res_users anymore to avoid locks on that table
