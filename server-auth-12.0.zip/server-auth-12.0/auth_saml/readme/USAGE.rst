#. Configure it (see corresponding section in README)
#. Just login with your SAML-provided password.
