* Checks to ensure no Odoo user with SAML also has an Odoo password.
* Setting to disable that rule.
