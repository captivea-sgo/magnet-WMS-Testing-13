1. Install the PyOTP library using pip: ``pip install pyotp``
2. Follow the standard module install process
