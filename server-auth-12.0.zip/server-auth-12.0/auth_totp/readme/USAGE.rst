If necessary, a user's trusted devices can be revoked by disabling and
re-enabling MFA for that user.
