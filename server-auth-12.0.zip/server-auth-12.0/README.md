[![Runbot Status](https://runbot.odoo-community.org/runbot/badge/flat/251/12.0.svg)](https://runbot.odoo-community.org/runbot/repo/github-com-oca-server-auth-251)
[![Build Status](https://travis-ci.org/OCA/server-auth.svg?branch=12.0)](https://travis-ci.org/OCA/server-auth)
[![codecov](https://codecov.io/gh/OCA/server-auth/branch/12.0/graph/badge.svg)](https://codecov.io/gh/OCA/server-auth)

Server Auth
===========

Authentication related modules.
