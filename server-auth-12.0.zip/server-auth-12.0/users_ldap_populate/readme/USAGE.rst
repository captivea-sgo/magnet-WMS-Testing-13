To use this module, you need to:

#. Go to 'Settings' -> 'General Settings'
#. In the LDAP category click on or add a LDAP configuration
#. In the pop-up enter all the LDAP settings
#. Click the populate button
#. A new pop-up will notify you of how many users are added
