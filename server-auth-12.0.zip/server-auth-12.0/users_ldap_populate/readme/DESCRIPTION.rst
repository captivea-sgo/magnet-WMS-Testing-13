This module extends the functionality of auth_ldap by adding functionality so
that users can be populated from a LDAP server.
