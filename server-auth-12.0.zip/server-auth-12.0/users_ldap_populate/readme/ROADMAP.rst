* Improve test coverage of the activativation of inactive users
