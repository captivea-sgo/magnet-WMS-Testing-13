This module Extends the existing functionality of Odoo Products
(One product - One Category) to One product -> Many Categories

*Note:* This module was built generically but in focus of the Magento
Odoo connector
*Note 2:* The additional categories are only for classification and does
not affect other operations
