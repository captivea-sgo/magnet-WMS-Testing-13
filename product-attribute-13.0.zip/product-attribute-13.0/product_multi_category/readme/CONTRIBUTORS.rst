* Raphaël Valyi <raphael.valyi@akretion.com>
* Renato Lima <renato.lima@akretion.com>
* Sébastien BEAU <sebastien.beau@akretion.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Sharoon Thomas
* Avanzosc
* Mikel Arregi <mikelarregi@avanzosc.es>
* SodexisTeam <dev@sodexis.com>
* Angel Moya <angel.moya@pesol.es>
* Sudhir Arya <sudhir@erpharbor.com>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
