from . import product_multi_price
from . import product_pricelist
from . import product_product
from . import product_template
