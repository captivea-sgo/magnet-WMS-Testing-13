To configure multiple prices you need to set multi prices field names first.
To do so, you need admin permissions. Then go to:

#. *Settings > Technical > Database Structure > Price Field Names*
#. Create the multi price fields you need.

If you have multiple companies, you can assign independent field sets for each
one.

Note: 'Show multi prices' access group must be checked to be able to
add multiple prices in the product form view.
