* Joao Alfredo Gama Batista <ermitaoj@gmail.com>
* Florian da Costa <florian.dacosta@akretion.com>
* Juan Humanes <juan.humanes@guadaltech.es>
* Thore Baden <thorebaden@gmail.com>
* Tony Galmiche <tony.galmiche@infosaone.com>
