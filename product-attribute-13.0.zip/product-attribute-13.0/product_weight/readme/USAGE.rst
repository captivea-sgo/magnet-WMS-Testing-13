You can update the weight of one product clicking on the button under
the weights.
Or you can select the products you want to update from the tree list.
