Allows to calculate products weight from its components.

You can update the weight for one specific product at a time
and choose which bom should be used to know the components.
Or you can run the calculation for many products at one time,
this way, the first bom found for the product will be used to know
the components.
