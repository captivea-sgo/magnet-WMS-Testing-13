[![Runbot Status](https://runbot.odoo-community.org/runbot/badge/flat/135/13.0.svg)](https://runbot.odoo-community.org/runbot/repo/github-com-oca-product-attribute-135)
[![Build Status](https://travis-ci.org/OCA/product-attribute.svg?branch=13.0)](https://travis-ci.org/OCA/product-attribute)
[![codecov](https://codecov.io/gh/OCA/product-attribute/branch/13.0/graph/badge.svg)](https://codecov.io/gh/OCA/product-attribute)

Odoo Product Attribute
======================

Various addons related to attribute management for products.
