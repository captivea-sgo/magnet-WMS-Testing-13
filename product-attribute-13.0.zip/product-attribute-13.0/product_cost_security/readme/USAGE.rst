To use this module you need to:

#. Go to product form view logged with this user and you will see the
   standard_price field.
