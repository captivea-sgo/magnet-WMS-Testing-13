Allows to reference tag records trough a unique code.
