* `C2i Change 2 improve <http://www.c2i.es>`_:

  * Eduardo Magdalena <emagdalena@c2i.es>
