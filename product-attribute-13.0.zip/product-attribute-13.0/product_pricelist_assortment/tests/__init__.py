from . import test_pricelist_assortment
