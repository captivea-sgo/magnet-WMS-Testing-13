This module allows to mark a product packaging type as required.

A cron creates the missing product packages if the related packaging type is required.
