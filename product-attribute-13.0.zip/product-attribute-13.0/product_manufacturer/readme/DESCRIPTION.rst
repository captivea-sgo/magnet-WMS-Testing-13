A module that adds manufacturers and attributes on the product form.

You can now define the following for a product
----------------------------------------------

* Manufacturer
* Manufacturer Product Name
* Manufacturer Product Code
* Manufacturer Product URL
