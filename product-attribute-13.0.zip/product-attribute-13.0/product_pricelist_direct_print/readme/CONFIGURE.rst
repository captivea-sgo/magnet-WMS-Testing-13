To configure this module, you need to:

#. Go to *Apps* and install *Sales Management*
#. Go to *Sales > Configuration > Settings*
#. Scroll to *Pricing*
#. Enable 'Pricelists'.

Users will need *Advanced Pricelists* to access the menus:

#. Enable developer mode
#. Go to *Settings > Users & Companies > Users*
#. Create or Edit a record
#. Scroll to *Technical Settings*
#. Enable *Advanced Pricelists*
