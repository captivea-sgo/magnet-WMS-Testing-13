To use this module, you have several options:

#. Go to *Sales > Products > Print Price List*

#. Go to *Sales > Products > Products*
    * Select products in list view
    * Press *Action > Price List*

#. Go to *Sales > Products > Product Variants*
    * Select products in list view
    * Press *Action > Price List*

#. Go to *Sales > Orders > Customers*
    * Select customers in list view
    * Press *Action > Send customer pricelist by EMail*
