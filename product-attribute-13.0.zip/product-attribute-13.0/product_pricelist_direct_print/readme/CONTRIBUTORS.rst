* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden <carlos.dauden@tecnativa.com>
  * David Vidal <david.vidal@tecnativa.com>
  * Sergio Teruel <sergio.teruel@tecnativa.com>

* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>
