Print price list from menu option, product templates, products variants or
price lists
