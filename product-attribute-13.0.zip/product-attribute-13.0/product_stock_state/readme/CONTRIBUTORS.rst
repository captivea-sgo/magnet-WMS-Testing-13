* Sebastien Beau <sebastien.beau@akretion.com>
* Sylvain LE GAL <https://www.twitter.com/legalsylvain>
* Kevin Khao <kevin.khao@akretion.com>
* Simone Orsi <simahawk@gmail.com>
