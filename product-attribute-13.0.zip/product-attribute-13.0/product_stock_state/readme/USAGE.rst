Open product tree view and observe the stock state

.. image:: /product_stock_state/static/description/product_product_tree.png
     :width: 800 px
