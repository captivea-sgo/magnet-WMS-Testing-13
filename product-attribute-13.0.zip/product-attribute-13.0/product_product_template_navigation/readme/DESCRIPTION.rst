This module adds a button in the product form to view the product template.

.. image:: ../static/img/template_navigation.gif
