* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Tecnativa - Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Aaron Henriquez <ahenriquez@forgeflow.com>
* Miquel Raïch <miquel.raich@forgeflow.com>
* Tecnativa - Sergio Teruel <sergio.teruel@tecnativa.com>
