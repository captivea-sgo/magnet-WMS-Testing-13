* Cedric Pigeon <cedric.pigeon@acsone.eu>
* Alexandre Saunier <alexandre.saunier@camptocamp.com>
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* Eduardo Magdalena <emagdalena@c2i.es> (C2i Change 2 improve http://www.c2i.es)
* Andrii Skrypka <andrijskrypa@ukr.net>
