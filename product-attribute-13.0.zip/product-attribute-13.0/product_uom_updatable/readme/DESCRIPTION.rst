Allow to change the product UoM if the new UoM is in the same category and has the same factor.
