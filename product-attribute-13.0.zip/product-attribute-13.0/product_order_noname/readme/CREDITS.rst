This module was created and is maintained by:

* Vauxoo, S.A. de C.V.

.. image:: http://www.vauxoo.com/logo.png
   :alt: Vauxoo, S.A. de C.V.
   :target: http://www.vauxoo.com
