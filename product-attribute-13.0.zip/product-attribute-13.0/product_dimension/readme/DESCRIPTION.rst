This module extends the functionality of product to support dimensions (length, width and height).
Also computes the volume automatically when you change one of these dimensions.

This module was previously hosted on https://github.com/ingadhoc/odoo-addons
and before that on https://launchpad.net/~ingenieria-adhoc.
