This module adds specific fields to manage product packaging types for pallets.
