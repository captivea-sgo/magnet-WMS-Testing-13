Adds ability to define a lot sequence from the product which will be proposed upon creating new lots.
