To use this module:

* Go to Inventory > Products
* Under the inventory tab when tracking set to lots 4 new fields will be displayed
* If a sequence is not selected, a new one using the prefix, padding and next number fields, will be created
* Go to Inventory > Lot/Serial Numbers
* Create new Lot/Serial number
* Select the product and the next number of the product sequence will be automatically proposed
