Click on the `Packaging price` buttons to use the wizard
