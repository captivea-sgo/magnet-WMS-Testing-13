from . import product_template
from . import medical_class
