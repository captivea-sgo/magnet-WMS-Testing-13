This module adds a Calendar to the Warehouse. This calendar can then used as
the basis of the proper computation of start/end dates based on lead times in
this and other modules.

In this module, the calendar considered in the computation of start date of
stock moves and pickings created from procurements, where the lead time
is used.
