* Go to *Settings* and activate the developer mode.

* Go to *Settings > Technical > Resource > Working Time* and define your
  resource calendar.

* Go to *Inventory > Configuration > Warehouse Management > Warehouses*
  and assign the Resource Calendar.

* Go to *Inventory > Configuration > Settings* and in *Warehouse* mark
  'Multi-Step Routes option'.

* Go to *Inventory > Configuration > Warehouse Management > Routes* and
  set up the proper delays in the stock rules where 'action'
  is 'Move From Another Location'.
