This module add the field "code" and "description" on the delivery carrier.
