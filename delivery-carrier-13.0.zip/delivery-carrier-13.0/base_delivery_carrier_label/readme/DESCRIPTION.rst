This module adds a button on delivery orders to generate a label as an
attachement. This module doesn't do anything by itself, it serves as a
base module for other carrier-specific modules.
