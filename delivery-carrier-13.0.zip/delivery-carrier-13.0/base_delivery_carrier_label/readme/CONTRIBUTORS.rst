* David BEAL <david.beal@akretion.com>
* Sébastien BEAU <sebastien.beau@akretion.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Angel Moya <angel.moya@pesol.es>
* Ismael Calvo <ismael.calvo@factorlibre.com>
* Dave Lasley <dave@laslabs.com>
* Timothée Ringeard <timothee.ringeard@camptocamp.com>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
