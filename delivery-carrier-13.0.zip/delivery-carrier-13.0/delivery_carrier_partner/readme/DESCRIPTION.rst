This module adds a *Transporter* field (link to a partner) in the delivery carrier.
