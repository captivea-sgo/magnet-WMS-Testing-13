* Agile Business Group
* Simone Rubino
* Valentin Vinagre Urteaga <valentin.vinagre@sygel.es>
* François Honoré <francois.honore@acsone.eu>
