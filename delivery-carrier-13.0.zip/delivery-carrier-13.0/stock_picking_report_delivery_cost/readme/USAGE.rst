To use this module, you need to:

#. Go to *Inventory > Operations > Transfers* and pick one not in state *Done*
   or *Cancelled*.
#. Click on *Print > Delivery Slip* or *Print > Picking Operations*.
#. You will see in the report the computed delivery cost.
