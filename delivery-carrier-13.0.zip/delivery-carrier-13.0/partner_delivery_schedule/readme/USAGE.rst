To use this module you need to:

#. Go to *Contacts > Create* or *Sales > Orders > Customers > Create*.
#. Go to *Sales and Purchases* tab.
#. Create new delivery hours for this partner in *Delivery Schedule* field.

You can set deliveries schedule directly in
*Sales > Configuration > Delivery Schedule*
