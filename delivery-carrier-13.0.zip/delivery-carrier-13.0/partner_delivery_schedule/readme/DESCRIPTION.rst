This module extends the functionality of delivery module to allow set delivery
hours and days for partners.
