* `Tecnativa <https://www.tecnativa.com>`__:

  * Vicent Cubells
  * Pedro M. Baeza

* `Camptocamp <https://www.camptocamp.com>`__:

  * Guewen Baconnier
  * Thierry Ducrest
