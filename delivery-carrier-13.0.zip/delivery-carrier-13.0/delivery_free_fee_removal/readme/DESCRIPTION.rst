This module hides free delivery lines from Sales reports. These lines
are not invoiceable, therefore not added in invoices.
