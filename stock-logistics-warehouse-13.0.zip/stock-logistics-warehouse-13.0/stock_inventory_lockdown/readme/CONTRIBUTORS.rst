* Loïc Bellier (Numérigraphe) <lb@numerigraphe.com>
* Lionel Sausin (Numérigraphe) <ls@numerigraphe.com>
* Laetitia Gangloff (Acsone) <laetitia.gangloff@acsone.eu>
* Laurent Mignon (Acsone) <laurent.mignon@acsone.eu>
* Lois Rilo (ForgeFlow) <lois.rilo@forgeflow.com>
* Jordi Ballester (ForgeFlow) <jordi.ballester@forgeflow.com>
* Michael Allen <mallen@opensourceintegrators.com>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
