This module adds the capability to navigate to inventory lines on validated
inventory adjustments.
