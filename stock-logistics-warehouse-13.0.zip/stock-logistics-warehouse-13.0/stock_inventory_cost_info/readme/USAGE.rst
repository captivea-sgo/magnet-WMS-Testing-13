To use this module, you need to:

#. Go to *Inventory > Operations > Inventory Adjustments* and create a new one.
#. Click on *Start Inventory* button.
#. In *Inventory Details* list you will see a new column named
   *Adjustment cost*.
#. The cost will be recomputed when the inventory adjustment is validated.
