This module extends the functionality of *Inventory Adjustments* to show a new
column *Adjustment cost* in *Inventory Details* list and PDF report table. The
value of *Adjustment cost* will be self-calculated according to:
(`Real Quantity` - `Theoretical Quantity`) * `Product Cost`
