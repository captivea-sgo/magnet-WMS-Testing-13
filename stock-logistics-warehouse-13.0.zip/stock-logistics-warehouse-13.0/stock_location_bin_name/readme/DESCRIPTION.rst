This module allows to compute automatically Bin location names based on
locations attributes.
