For a properly usage of this module, you must:

- Ensure: Inventory > Settings > Inventory Adjustment > Preset Change Qty Reason is enabled

To allow an Stock Manager configure accounts in preset reasons easily, you should:

- Select Stock Manager user on: Settings > Users
- Enable: Technical Settings > Manage Stock Change Qty Preset Reasons
- Go to Inventory > Configuration > Inventory Adjustment > Change Qty Reasons
