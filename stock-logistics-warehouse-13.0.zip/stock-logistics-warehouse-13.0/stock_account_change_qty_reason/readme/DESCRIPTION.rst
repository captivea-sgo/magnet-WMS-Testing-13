This module extends the product stock management and allows to assign specific account
to manage changes on product quantities, either from product wizard or inventory adjustments.
