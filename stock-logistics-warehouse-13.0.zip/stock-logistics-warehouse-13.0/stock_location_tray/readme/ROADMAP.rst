The buttons on operations opens a view with the tray matrix to show operators
where to pick/put goods. The issue is that Odoo allows only one modal popup
to be open at a time. The tray matrix replaces the operations window. We have
to find a way to prevent this. The tray matrix could be displayed through a
tooltip maybe, if we find how to render a widget in a tooltip.
