This module adds the stock move to the account move lines that it generates.
