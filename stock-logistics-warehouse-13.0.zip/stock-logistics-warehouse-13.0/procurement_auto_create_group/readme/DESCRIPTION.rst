This module allows the system to propose automatically new procurement groups
during the procurement run.

This capability is important when you want to make sure that all the stock
moves resulting from a procurement run will never be mixed with moves from
other groups in stock transfers.

The stock transfers resulting from the procurement run will
only contain stock moves created in that run.
