#. Run a new procurement and make sure that it determines a pull rule
   with the option 'Auto-create Procurement Group' set.
#. When the procurement rule is executed, a procurement group with
   format 'PG/000001' will be created.
