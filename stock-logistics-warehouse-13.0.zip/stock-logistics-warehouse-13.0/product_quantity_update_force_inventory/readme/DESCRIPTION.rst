With this module, when a user goes to a product and presses the button 'Update Quantity' they will be directed to a new
Inventory Adjustment for this product, instead of driving the user to update the quantities in the
stock quants.

By doing this users will be able to have full traceability on the inventory adjustment activities.

Consider using this module together with the module 'stock_change_qty_reason'
(https://github.com/OCA/stock-logistics-warehouse/tree/13.0/stock_change_qty_reason).
