Cubiscan_ are dimensioners for cubing and weighing in warehouses.
This module implements the communication with the dimensioners as well
as a screen to measure and weight packaging of the products.

.. _Cubiscan: https://cubiscan.com/
