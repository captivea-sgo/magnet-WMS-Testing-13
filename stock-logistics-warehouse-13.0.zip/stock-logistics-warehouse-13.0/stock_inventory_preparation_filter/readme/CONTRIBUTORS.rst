* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * David Vidal
  * Sergio Teruel

* Xavier Jimenez <xavier.jimenez@qubiq.es>
