* The widget domain is not displayed correctly, but this issue is related to
  Odoo. To avoid this malfunction, use the keyboard arrows to properly work
  with the domain option.
