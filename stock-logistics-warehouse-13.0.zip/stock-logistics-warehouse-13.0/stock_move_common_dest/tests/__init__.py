from . import test_move_common_dest
