Go to Inventory > Configuration > Scrap Reason Codes

Create a required scrap reason code and provide scrap location.
