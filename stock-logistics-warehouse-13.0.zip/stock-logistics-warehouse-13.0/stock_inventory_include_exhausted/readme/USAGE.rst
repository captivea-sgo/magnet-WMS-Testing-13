To use this module, you simply need to:

#. Create a new inventory adjustment.
#. Select the products that you want to do the inventory.
#. Check the box "Include Exhausted".
#. Press the button Start Inventory
