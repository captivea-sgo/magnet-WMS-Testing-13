This module provides unittests for module `base_time_window`.
