from . import partner_time_window
from . import res_partner
