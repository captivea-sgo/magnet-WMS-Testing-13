* Laurent Mignon <laurent.mignon@acsone.eu>
* Akim Juillerat <akim.juillerat@camptocamp.com>
