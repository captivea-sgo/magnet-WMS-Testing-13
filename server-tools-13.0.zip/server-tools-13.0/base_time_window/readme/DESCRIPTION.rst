This module provides base classes and models to manage time windows through
`time.window.mixin`.
