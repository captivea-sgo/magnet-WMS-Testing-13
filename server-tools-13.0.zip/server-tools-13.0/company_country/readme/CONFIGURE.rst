To configure this module, you need to:

#. Set the environment variable ``COUNTRY`` using a two-letter ISO 3166 code.
