To install this module, you need to:

#. Add it as dependency from your main module.
