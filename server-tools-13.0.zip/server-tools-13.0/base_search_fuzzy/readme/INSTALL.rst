#. The PostgreSQL extension ``pg_trgm`` should be available. In debian based
   distribution you have to install the `postgresql-contrib` module.
#. Install the ``pg_trgm`` extension to your database or give your postgresql
   user the ``SUPERUSER`` right (this allows the odoo module to install the
   extension to the database).
