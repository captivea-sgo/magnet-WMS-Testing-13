* Modify the general search parts (e.g. in tree view or many2one fields)
* Add better `order by` handling
