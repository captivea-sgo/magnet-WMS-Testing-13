This module allows to test fetchmail_notify_error_to_sender without installing
test_mail.
For more info please check comment:
https://github.com/OCA/server-tools/pull/1485#discussion_r289751883
