Test data for addon_hash module.
