Just type into any field with translated term, such as Product on a Sale Order.
