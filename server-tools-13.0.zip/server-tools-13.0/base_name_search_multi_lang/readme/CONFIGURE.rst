Additional search fields can be configured at Settings > Technical > Database > Models,
using the "Search Translated Name" field.
