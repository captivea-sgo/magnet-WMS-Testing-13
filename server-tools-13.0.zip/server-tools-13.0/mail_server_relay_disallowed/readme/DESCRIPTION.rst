Fixes the issue of using a mail client where relaying is disallowed.
See:
https://www.odoo.com/es_ES/forum/help-1/question/zoho-com-connection-unexpectedly-closed-51162
