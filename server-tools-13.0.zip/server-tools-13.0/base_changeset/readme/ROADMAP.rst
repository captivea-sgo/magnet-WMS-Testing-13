* Only a subset of the type of fields is actually supported
* Multicompany not fully supported
