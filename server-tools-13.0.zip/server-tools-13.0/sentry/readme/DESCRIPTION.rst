This module allows painless `Sentry <https://sentry.io/>`__ integration with
Odoo.
