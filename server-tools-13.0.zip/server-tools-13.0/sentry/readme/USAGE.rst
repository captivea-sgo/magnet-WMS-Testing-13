Once configured and installed, the module will report any logging event at and
above the configured Sentry logging level, no additional actions are necessary.

.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Try me on Runbot
   :target: https://runbot.odoo-community.org/runbot/149/13.0
