This module adds a new Many2many custom field with a `create_table` attribute.
