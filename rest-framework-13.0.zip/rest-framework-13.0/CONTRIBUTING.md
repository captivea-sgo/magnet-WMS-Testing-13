# OCA Guidelines

Please follow the official guide from the [OCA Guidelines page](https://github.com/OCA/maintainer-tools/blob/master/CONTRIBUTING.md).

## Project Specific Guidelines

This project does not have specific coding guidelines.
