# Copyright 2018 ACSONE SA/NV
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from .controllers import GraphQLControllerMixin
from .types import OdooObjectType
